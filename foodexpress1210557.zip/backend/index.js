const express = require('express');
const app = express();
const port = 4000;
const connectToDB = require("./db");
const createUserRoute = require("./Routes/createUser");
const DisplayDataRoute = require("./Routes/DisplayData");

app.use(express.json());

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "http://localhost:3000");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});

connectToDB();

app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.use('/api', createUserRoute);
app.use('/api', DisplayDataRoute);

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});