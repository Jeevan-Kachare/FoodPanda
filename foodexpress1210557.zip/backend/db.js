const mongoose = require('mongoose');
mongoose.set('debug', true);
const monogoURI = "mongodb+srv://kacharejeevan:Jeevank@cluster0.ec92rqa.mongodb.net/Foodexpress2?retryWrites=true&w=majority";

const connectToDB = async () => {
  try {
    await mongoose.connect(monogoURI, { useNewUrlParser: true });
    console.log('Connected successfully');

    const fooditem1 = await mongoose.connection.db.collection("Fooditem").find({}).toArray();
    const foodCatogery1 = await mongoose.connection.db.collection("FoodCatogery").find({}).toArray();
    global.fooditem=fooditem1;
    global.foodCatogery=foodCatogery1;
    console.log(fooditem1);
    console.log(foodCatogery1);
  } catch (error) {
    console.log('Error connecting to the database:', error);
  }
};

module.exports = connectToDB;