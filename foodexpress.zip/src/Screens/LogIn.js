import React from 'react'

export default function LogIn() {
  return (
    <div>LogIn</div>
  )
}
