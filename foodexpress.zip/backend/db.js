const mongoose = require('mongoose');
mongoose.set('debug', true);
const monogoURI = "mongodb+srv://kacharejeevan:Jeevank@cluster0.ec92rqa.mongodb.net/Foodexpress2?retryWrites=true&w=majority";

const connectToDB = async () => {
  try {
    await mongoose.connect(monogoURI, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected successfully');
  } catch (error) {
    console.log('Error connecting to the database:', error);
  }
};

module.exports = connectToDB;