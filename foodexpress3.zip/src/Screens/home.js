import React from 'react'
import Navbar from '../compoents/Navbar'
import Footer from '../compoents/Footer'
import Card from '../compoents/Card'
import Carousal from '../compoents/Carousal'

export default function() {
  return (
    <>
    <div>
        <Navbar/>
    </div>
    <div>
      <Carousal/>
    </div>
    <div className='m-3'> 
              <Card/>
              <Card/>
              <Card/>
              <Card/>
        
    </div>
    <div>
        <Footer/>
    </div>
    </>

  )
}
