import React from 'react'
import Navbar from '../compoents/Navbar'
import Footer from '../compoents/Footer'

export default function() {
  return (
    <>
    <div>
        <Navbar/>
    </div>
    <div>
                body
        
    </div>
    <div>
        <Footer/>
    </div>
    </>

  )
}
