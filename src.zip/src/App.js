import './App.css';
import Home from './Screens/home';
import Navbar from './compoents/Navbar';

function App() {
  return (
<div><Home/></div>
  );
}

export default App;
