import './App.css';
import LogIn from './Screens/LogIn';
import Home from './Screens/home';
import Navbar from './compoents/Navbar';
import { BrowserRouter as Router, Routes, Route , Link} from "react-router-dom";

function App() {
  return (
    <Router>
      <div>
      <Routes>
        <Route exact path="/" element={<Home/>} />
        <Route exact path="/login" element={<LogIn/>} />
      </Routes>
    </div>
    </Router>

  );
}

export default App;
