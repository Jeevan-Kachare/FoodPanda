import React, { useEffect, useState } from 'react';
import Navbar from '../compoents/Navbar';
import Footer from '../compoents/Footer';
import Card from '../compoents/Card';
import Carousal from '../compoents/Carousal';

export default function Home() {

  const [search, setSearch] = useState("");
  const [foodcat, setfoodcat] = useState([]);
  const [fooditem, setfooditem] = useState([]);

  const loaddata = async () => {
    let response = await fetch("http://localhost:4000/api/fooddata", {
      method: "POST",
      headers: {
        'Content-Type': 'application/json'
      }
    });

    response = await response.json();

    setfoodcat(response[1]);
    setfooditem(response[0]);
    console.log(response);
    //, response[1]
  };

  useEffect(() => {
    loaddata();
  }, []);

  return (
    <div>
      <div>
        <Navbar />
      </div>
      <div>
        <div id="carouselExampleControls" className="carousel slide" data-bs-ride="carousel" style={{objectFit:"contain !important"}}>
          <div className="carousel-inner" id='carousal'>
            <div className="carousel-caption" style={{zIndex:"10"}}>
              <div class="d-flex justify-content-center">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" value={search} onChange={(e)=>{setSearch(e.target.value)}} />
           
              </div>
            </div>
            <div className="carousel-item active">
              <img src="https://source.unsplash.com/random/900×700/?burger" className="d-block w-100" alt="..."/>
            </div>
            <div className="carousel-item">
              <img src="https://source.unsplash.com/random/900×700/?pastry" className="d-block w-100" alt="..."/>
            </div>
            <div className="carousel-item">
              <img src="https://source.unsplash.com/random/900×700/?barbeque" className="d-block w-100" alt="..."/>
            </div>
          </div>
          <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
            <span className="carousel-control-prev-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Previous</span>
          </button>
          <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
            <span className="carousel-control-next-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Next</span>
          </button>
        </div>
      </div>
      <div className='container'>
        {foodcat !== [] ? (
          foodcat.map((data) => {
            return (
              <div className="row mb-3" key={data.id}>
                <div>
                  <div className="fs-3 m-3">{data.CategoryName}</div>
                  <hr />
                  {fooditem !== [] ? (
                    <div className="row">
                      {fooditem
                        .filter((item) => item.CategoryName === data.CategoryName && (item.name.toLowerCase().includes(search.toLocaleLowerCase()))) 
                        .map((filterItems) => {
                          return (
                            <div key={filterItems.id} className="col-12 col-md-6 col-lg-3">
                              <Card fooditem={filterItems}
                              
                               imgSrc={filterItems.img} />
                            </div>
                          );
                        })}
                    </div>
                  ) : (
                    <div>No such data found</div>
                  )}
                </div>
              </div>
            );
          })
        ) : (
          <div>No data found</div>
        )}
      </div>
      <div>
        <Footer />
      </div>
    </div>
  );
}