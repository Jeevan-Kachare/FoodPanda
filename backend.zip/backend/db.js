const mongoose = require('mongoose');
const monogoURI = "mongodb+srv://kacharejeevan:Jeevank@cluster0.ec92rqa.mongodb.net/Foodexpress2?retryWrites=true&w=majority";

const mongoDB = async () => {
  try {
    await mongoose.connect(monogoURI, { useNewUrlParser: true });
    console.log('Connected successfully');
    const fetcheddata = await mongoose.connection.db.collection("Fooditem");
    const data = await fetcheddata.find({}).toArray();
    console.log(data);
  } catch (error) {
    console.log('Error connecting to the database:', error);
  } finally {
    mongoose.disconnect();
  }
};

module.exports = mongoDB;