const mongoose = require('mongoose');
const monogoURI = "mongodb+srv://kacharejeevan:Jeevank@cluster0.ec92rqa.mongodb.net/Foodexpress?retryWrites=true&w=majority";

const mongoDB = async () => {
  try {
    await mongoose.connect(monogoURI, { useNewUrlParser: true });
    console.log('Connected successfully');
  } catch (error) {
    console.log('Error connecting to the database:', error);
  }
};

module.exports = mongoDB;