const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.post("/createuser", async (req, res) => {
  try {
    const { name, password, email, location } = req.body;

    // Create a new user instance
    const newUser = new User({
        name: req.body.name,
        password: req.body.password,
        email: req.body.email,
        location: req.body.location
    });

    // Save the user to the database
    await newUser.save();

    res.json({ success: true });
  } catch (error) {
    console.log(error);
    res.json({ success: false });
  }
});

module.exports = router;