const express = require('express');
const router = express.Router();

router.post('/fooddata',(req,res)=>{
    try{

        console.log(global.fooditem);
        res.send([global.fooditem,global.foodCatogery]);
    }catch(error)
    {
            console.error(error.message);
            res.send("server errro");
    }
})


module.exports = router;