import React, { useEffect, useState } from 'react';
import Navbar from '../compoents/Navbar';
import Footer from '../compoents/Footer';
import Card from '../compoents/Card';
import Carousal from '../compoents/Carousal';

export default function Home() {
  const [foodcat, setfoodcat] = useState([]);
  const [fooditem, setfooditem] = useState([]);

  const loaddata = async () => {
    let response = await fetch("http://localhost:4000/api/fooddata", {
      method: "POST",
      headers: {
        'Content-Type': 'application/json'
      }
    });

    response = await response.json();

    setfoodcat(response[1]);
    setfooditem(response[0]);
    console.log(response);
    //, response[1]
  };

  useEffect(() => {
    loaddata();
  }, []);

  return (
    <>
      <div>
        <Navbar />
      </div>
      <div>
        <Carousal />
      </div>
      <div className='container'>
        {foodcat !== [] ? (
          foodcat.map((data) => {
            return (
              <div className="row mb-3" key={data.id}>
                <div>
                  <div className="fs-3 m-3">{data.CatogeryName}</div>
                  <hr />
                  {fooditem !== [] ? (
                    <div className="row">
                      {fooditem
                        .filter((item) => item.CatogeryName === data.CatogeryName)
                        .map((filterItems) => {
                          return (
                            <div key={filterItems.id} className="col-12 col-md-6 col-lg-3">
                              <Card />
                            </div>
                          );
                        })}
                    </div>
                  ) : (
                    <div>No such data found</div>
                  )}
                </div>
              </div>
            );
          })
        ) : (
          <div>No data found</div>
        )}
      </div>
      <div>
        <Footer />
      </div>
    </>
  );
}